def contoh_pertama():
    row = int(input('Masukan jumlah baris yang diinginkan : '))

    for i in range(0, row):
        for k in range(0, i+1):
            print('* ', end=' ')
        print()


def contoh_kedua():
    row = int(input('Masukan jumlah baris yang diinginkan : '))
    star = ''

    for i in range(0, row):
        for _ in range(0, i+1):
            star += '* '
        star += '\n'
    print(star, end=' ')


contoh_pertama()
